using Mirror;
using UnityEngine;

public class FighterHealth : NetworkBehaviour
{
        [SyncVar(hook = nameof(OnHealthChanged))]
        public int currentHealth;
        public static FighterHealth localPlayerHealth;


        public int maxHealth = 100;

    public bool isDead = false;

    public override void OnStartServer()
    {
        currentHealth = maxHealth;
    }

    [Server]
    public override void OnStartLocalPlayer()
    {
        localPlayerHealth = this;
    }

    [Server]
    public void TakeDamage(int amount)
    {
        if (isDead) return;

        currentHealth -= amount;

        if (currentHealth <= 0)
        {
            currentHealth = 0;
            isDead = true;

            RpcOnKO(netId);
        }
    }


    void OnHealthChanged(int oldValue, int newValue)
    {
        
    }

    [ClientRpc]
    void RpcOnKO(uint deadPlayerId)
    {
        Animator anim = GetComponent<Animator>();
        anim.Play("knockout", 0, 0f);

        Vector3 p = transform.position;
        p.y = 3.09f;
        transform.position = p;

        // Is dit de local player die KO is?
        bool iAmDead = (NetworkClient.localPlayer != null &&
                        NetworkClient.localPlayer.netId == deadPlayerId);

        // Toon end screen
        EndScreenManager.Instance.ShowEndScreen(!iAmDead);
    }

}
