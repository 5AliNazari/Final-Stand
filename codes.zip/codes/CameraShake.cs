using UnityEngine;

public class CameraShake : MonoBehaviour
{
    public static CameraShake Instance;

    Vector3 originalPos;

    void Awake()
    {
        Instance = this;
        originalPos = transform.localPosition;
    }

    public void Shake(float intensity, float duration)
    {
        StopAllCoroutines();
        StartCoroutine(DoShake(intensity, duration));
    }

    System.Collections.IEnumerator DoShake(float intensity, float duration)
    {
        float timer = 0f;

        while (timer < duration)
        {
            // Alleen links-rechts, met LIMIT zodat hij niet te ver gaat
            float x = Random.Range(-1f, 1f) * intensity;

            // LIMIT zodat hij nooit te ver uitslaat
            x = Mathf.Clamp(x, -intensity, intensity);

            transform.localPosition = originalPos + new Vector3(x, 0, 0);

            timer += Time.deltaTime;
            yield return null;
        }

        transform.localPosition = originalPos;
    }
}
