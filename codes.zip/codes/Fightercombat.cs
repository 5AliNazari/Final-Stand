﻿using Mirror;
using UnityEngine;
using System.Collections;

public class FighterCombat : NetworkBehaviour
{
    [Header("FX")]
    public GameObject hitSparkPrefab;


    public enum AttackType
    {
        Jab,
        Cross,
        Hook,
        Uppercut
    }

    [HideInInspector]
    public AttackType currentAttack;

    [SyncVar] public bool isBlocking = false;
    [SyncVar] public int remainingBlocks = 0;

    [Command]
    public void CmdStartBlock()
    {
        isBlocking = true;
        remainingBlocks = 2;
    }

    [Command]
    public void CmdStopBlock()
    {
        isBlocking = false;
        remainingBlocks = 0;
    }

    // ---------------------------------------------------------
    // ATTACK SYNC (BELANGRIJK VOOR JUISTE HIT ANIMATIE)
    // ---------------------------------------------------------
    [Command]
    void CmdSetAttack(int attackType)
    {
        currentAttack = (AttackType)attackType;
    }

    // ---------------------------------------------------------
    // ANIMATION EVENTS
    // ---------------------------------------------------------

    public void OnPunchHitFrame()
    {
        if (!isLocalPlayer) return;
        currentAttack = AttackType.Jab;
        CmdSetAttack((int)AttackType.Jab);
        CmdTryHit();
    }

    public void OnCrossHitFrame()
    {
        if (!isLocalPlayer) return;
        currentAttack = AttackType.Cross;
        CmdSetAttack((int)AttackType.Cross);
        CmdTryHit();
    }

    public void OnHookHitFrame()
    {
        if (!isLocalPlayer) return;
        currentAttack = AttackType.Hook;
        CmdSetAttack((int)AttackType.Hook);
        CmdTryHit();
    }

    public void OnUppercutHitFrame()
    {
        if (!isLocalPlayer) return;
        currentAttack = AttackType.Uppercut;
        CmdSetAttack((int)AttackType.Uppercut);
        CmdTryHit();
    }

    // ---------------------------------------------------------
    // DAMAGE PER ATTACK
    // ---------------------------------------------------------
    int GetDamageForAttack(AttackType type)
    {
        switch (type)
        {
            case AttackType.Jab: return 5;
            case AttackType.Cross: return 10;
            case AttackType.Hook: return 14;
            case AttackType.Uppercut: return 18;
            default: return 10;
        }
    }

    // ---------------------------------------------------------
    // SERVER HIT DETECTION
    // ---------------------------------------------------------
    [Command]
    void CmdTryHit()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position + transform.forward * 1f, 0.7f);

        foreach (Collider hit in hits)
        {
            FighterHealth target = hit.GetComponent<FighterHealth>();
            FighterCombat targetCombat = hit.GetComponent<FighterCombat>();

            if (target != null && target != GetComponent<FighterHealth>())
            {
                uint defenderId = target.netId;
                int dmg = GetDamageForAttack(currentAttack);

                if (targetCombat != null && targetCombat.isBlocking && targetCombat.remainingBlocks > 0)
                {
                    targetCombat.remainingBlocks--;
                    dmg = 0;

                    RpcPlayHitAnimation(defenderId, "hit_block");

                    if (targetCombat.remainingBlocks <= 0)
                        targetCombat.isBlocking = false;
                }
                else
                {
                    if (currentAttack == AttackType.Uppercut)
                        RpcPlayHitAnimation(defenderId, "hit_uppercut");
                    else
                        RpcPlayHitAnimation(defenderId, "hit_head");
                }

                target.TakeDamage(dmg);

                Vector3 hitPoint = hit.ClosestPoint(transform.position);
                uint attackerId = netId;

                RpcHitEffects(hitPoint, attackerId, defenderId);

                return;
            }
        }
    }

    // ---------------------------------------------------------
    // HIT ANIMATION RPC (LOCAL + ANDERE CLIENTS)
    // ---------------------------------------------------------
    [ClientRpc]
    void RpcPlayHitAnimation(uint defenderId, string animName)
    {
        // 1. Local player zelf
        if (NetworkClient.localPlayer != null &&
            NetworkClient.localPlayer.netId == defenderId)
        {
            Animator localAnim = NetworkClient.localPlayer.GetComponent<Animator>();
            localAnim.Play(animName, 0, 0f);

            PlayerMovement pm = NetworkClient.localPlayer.GetComponent<PlayerMovement>();
            if (pm != null)
                pm.ForceHitLock(0.35f);   // 0.35s geen eigen animaties

            return;
        }

        // 2. Andere spelers
        if (NetworkClient.spawned.TryGetValue(defenderId, out NetworkIdentity id))
        {
            Animator anim = id.GetComponent<Animator>();
            anim.Play(animName, 0, 0f);
        }
    }

    // ---------------------------------------------------------
    // CLIENT FX
    // ---------------------------------------------------------
    [ClientRpc]
    void RpcHitEffects(Vector3 pos, uint attackerId, uint defenderId)
    {
        if (hitSparkPrefab != null)
            Instantiate(hitSparkPrefab, pos + Vector3.up * 0.3f, Quaternion.identity);

        if (NetworkClient.localPlayer != null &&
            NetworkClient.localPlayer.netId == attackerId)
        {
            CameraShake.Instance.Shake(0.55f, 0.08f);
        }

        if (NetworkClient.localPlayer != null &&
            NetworkClient.localPlayer.netId == defenderId)
        {
            CameraShake.Instance.Shake(0.35f, 0.12f);
            ApplyKnockback(NetworkClient.localPlayer.transform, currentAttack);
        }

        if (NetworkClient.localPlayer != null &&
            (NetworkClient.localPlayer.netId == attackerId ||
             NetworkClient.localPlayer.netId == defenderId))
        {
            CameraShake.Instance.StartCoroutine(Hitstop(0.04f));
        }
    }

    // ---------------------------------------------------------
    // KNOCKBACK
    // ---------------------------------------------------------
    void ApplyKnockback(Transform target, AttackType attack)
    {
        Rigidbody rb = target.GetComponent<Rigidbody>();
        if (rb == null) return;

        Vector3 dir = (target.position - transform.position).normalized;

        float force = 0f;

        switch (attack)
        {
            case AttackType.Jab: force = 2f; break;
            case AttackType.Cross: force = 3.5f; break;
            case AttackType.Hook: force = 5f; break;
            case AttackType.Uppercut: force = 7f; break;
        }

        rb.AddForce(dir * force, ForceMode.Impulse);
    }

    // ---------------------------------------------------------
    // HITSTOP
    // ---------------------------------------------------------
    IEnumerator Hitstop(float duration)
    {
        Time.timeScale = 0f;
        yield return new WaitForSecondsRealtime(duration);
        Time.timeScale = 1f;
    }
}
