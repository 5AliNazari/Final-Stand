﻿using UnityEngine;
using UnityEngine.UI;
using Mirror;

public class EnemyHealthBarUI : NetworkBehaviour
{
    public Slider healthSlider;
    private FighterHealth health;

    void Start()
    {
        health = GetComponent<FighterHealth>();

        // Verberg je eigen rode balk
        if (isLocalPlayer)
        {
            healthSlider.gameObject.SetActive(false);
        }

        healthSlider.maxValue = health.maxHealth;
        healthSlider.value = health.currentHealth;
    }

    void Update()
    {
        healthSlider.value = health.currentHealth;
    }
}