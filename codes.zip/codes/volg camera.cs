﻿using UnityEngine;

public class FollowCamera : MonoBehaviour
{
    public Transform player;
    public Vector3 offset = new Vector3(0, 9, -17);
    Vector3 velocity = Vector3.zero;

    void LateUpdate()
    {
        if (player == null) return;

        Vector3 rotatedOffset = player.rotation * offset;
        Vector3 targetPosition = player.position + rotatedOffset;

        transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, 0.2f);
        transform.LookAt(player);
    }
}