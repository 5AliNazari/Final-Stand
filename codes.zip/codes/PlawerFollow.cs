using UnityEngine;
using Mirror;

public class PlayerCameraController : NetworkBehaviour
{
    public GameObject cameraPrefab;

    private GameObject camInstance;

    public override void OnStartLocalPlayer()
    {
        // Camera alleen voor de lokale speler
        camInstance = Instantiate(cameraPrefab);

        // Koppel de camera aan deze speler
        camInstance.GetComponent<FollowCamera>().player = transform;
    }
}