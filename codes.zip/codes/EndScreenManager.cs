﻿using UnityEngine;
using TMPro;

public class EndScreenManager : MonoBehaviour
{
    public static EndScreenManager Instance;

    public GameObject endScreenPanel;
    public TMP_Text resultText;

    public GameObject panelMain;   // <-- voeg toe
    public GameObject panelPlay;   // <-- voeg toe

    void Awake()
    {
        Instance = this;
        endScreenPanel.SetActive(false);
    }

    public void ShowEndScreen(bool youWon)
    {
        endScreenPanel.SetActive(true);

        if (youWon)
            resultText.text = "YOU WON";
        else
            resultText.text = "YOU LOST";

        // Cursor vrijmaken zodat je knoppen kan klikken
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    public void PlayAgain()
    {
        // Endscreen weg
        endScreenPanel.SetActive(false);

        // Ga naar Panel_Play
        panelMain.SetActive(false);
        panelPlay.SetActive(true);

        // Cursor blijft vrij
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    public void BackToMenu()
    {
        // Endscreen weg
        endScreenPanel.SetActive(false);

        // Ga naar Panel_Main
        panelMain.SetActive(true);
        panelPlay.SetActive(false);

        // Cursor blijft vrij
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    public void ExitGame()
    {
        Application.Quit();
    }
}
