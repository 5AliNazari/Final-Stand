using UnityEngine;
using UnityEngine.UI;
using Mirror;

public class PlayerHealthBarUI : MonoBehaviour
{
    public Slider healthSlider;
    private FighterHealth health;

    void Start()
    {
        // Zoek de local player
        foreach (var player in FindObjectsByType<FighterHealth>(FindObjectsSortMode.None))
        {
            if (player.isLocalPlayer)
            {
                health = player;
                break;


            }
        }

        if (health != null)
            healthSlider.maxValue = health.maxHealth;
    }

    void Update()
    {
        if (health != null)
            healthSlider.value = health.currentHealth;
    }
}