﻿using UnityEngine;
using Mirror;

public class PlayerMovement : NetworkBehaviour
{
    public float speed = 5f;
    public float rotationSpeed = 350f;
    public Camera playerCamera;

    Animator anim;
    private bool isLocked = false;
    private string currentAnim = "";
    Rigidbody rb;

    FighterCombat combat;

    bool isReady = false;

    // NIEUW: lock door hit
    float hitLockTimer = 0f;

    public override void OnStartLocalPlayer()
    {
        isReady = true;
    }

    void Start()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody>();
        combat = GetComponent<FighterCombat>();

        if (isLocalPlayer)
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;

            if (playerCamera != null)
                playerCamera.gameObject.SetActive(true);
        }

        rb.interpolation = RigidbodyInterpolation.Interpolate;
    }

    void Update()
    {
        if (!isLocalPlayer || !isReady) return;

        // ALS JE NET GEHIT BENT → GEEN INPUT/ANIMS OVERSCHRIJVEN
        if (hitLockTimer > 0f)
        {
            hitLockTimer -= Time.deltaTime;
            return;
        }

        AnimatorStateInfo stateInfo = anim.GetCurrentAnimatorStateInfo(0);

        if (isLocked && stateInfo.normalizedTime >= 1f)
        {
            isLocked = false;
            currentAnim = "";
        }

        if (!isLocked)
        {
            float h = Input.GetAxisRaw("Horizontal");
            float v = Input.GetAxisRaw("Vertical");

            if (v > 0)
                PlayLocked("Fwalk", false);
            else if (v < 0)
                PlayLocked("Bwalk", false);
            else if (h > 0)
                PlayLocked("Rwalk", false);
            else if (h < 0)
                PlayLocked("Lwalk", false);
            else if (Input.GetKeyDown(KeyCode.C))
                PlayLocked("jab");
            else if (Input.GetKeyDown(KeyCode.V))
                PlayLocked("cross");
            else if (Input.GetKeyDown(KeyCode.G))
                PlayLocked("hook");
            else if (Input.GetKeyDown(KeyCode.B))
                PlayLocked("uppercut");
            else if (Input.GetKeyDown(KeyCode.F))
                PlayLocked("Lhook");
            else if (Input.GetKeyDown(KeyCode.Mouse1))
            {
                PlayLocked("block");
                combat.CmdStartBlock();
            }
            else if (Input.GetKeyDown(KeyCode.X))
                PlayLocked("Dodge_Backward");
            else if (Input.GetKeyDown(KeyCode.E))
                PlayLocked("Dodge_Right");
            else if (Input.GetKeyDown(KeyCode.R))
                PlayLocked("Dodge_Left");
            else
                PlayLocked("Idle", false);
        }

        // 🔥 TOEGEVOEGD: camera draait alleen als cursor gelockt is
        if (Cursor.lockState == CursorLockMode.Locked)   // <---
        {
            if (Input.GetMouseButton(0))
            {
                float mouseX = Input.GetAxisRaw("Mouse X");
                transform.Rotate(Vector3.up * mouseX * rotationSpeed * Time.deltaTime);
            }
        }
        // 🔥 EINDE TOEVOEGING
    }

    void FixedUpdate()
    {
        if (!isLocalPlayer || !isReady) return;

        // ook hier: geen movement als je net gehit bent
        if (hitLockTimer > 0f)
            return;

        float moveH = Input.GetAxis("Horizontal");
        float moveV = Input.GetAxis("Vertical");

        Vector3 move = transform.forward * moveV + transform.right * moveH;

        if (move.magnitude > 1f)
            move.Normalize();

        rb.MovePosition(rb.position + move * speed * Time.fixedDeltaTime);
    }

    void PlayLocked(string animName, bool lockAnim = true)
    {
        if (animName != "Idle")
            CmdPlayAnimation(animName);

        anim.Play(animName, 0, 0f);

        currentAnim = animName;
        isLocked = lockAnim;
    }

    [Command]
    void CmdPlayAnimation(string animName)
    {
        RpcPlayAnimation(animName);
    }

    [ClientRpc]
    void RpcPlayAnimation(string animName)
    {
        anim.Play(animName, 0, 0f);
    }

    // NIEUW: wordt aangeroepen door FighterCombat bij hit
    public void ForceHitLock(float duration)
    {
        hitLockTimer = duration;
        isLocked = true;
    }
}
