﻿using UnityEngine;
using Mirror;
using TMPro;

public class MenuManager : MonoBehaviour
{
    public GameObject mainMenu;      // Panel_Main
    public GameObject playMenu;      // Panel_Play
    public GameObject controlsMenu;  // Panel_Controls

    public GameObject createButton;
    public GameObject joinButton;

    public GameObject connectionPanel;
    public GameObject joinGameButton;

    public TMP_InputField ipField;
    public TMP_InputField portField;

    public NetworkManager networkManager;

    private void Update()
    {
        // Host is actief en er zijn 2 spelers → menu sluiten
        if (NetworkServer.active && NetworkServer.connections.Count == 2)
        {
            playMenu.SetActive(false);
        }

        // Client is verbonden → menu sluiten
        if (NetworkClient.isConnected && !NetworkServer.active)
        {
            playMenu.SetActive(false);
        }
    }

    public void ShowPlay()
    {
        mainMenu.SetActive(false);
        playMenu.SetActive(true);

        // Reset UI
        createButton.SetActive(true);
        joinButton.SetActive(true);
        connectionPanel.SetActive(false);
        joinGameButton.SetActive(false);
    }
    public void ShowMain()
    {
        mainMenu.SetActive(true);
        playMenu.SetActive(false);
        controlsMenu.SetActive(false);
    }
    public void ShowControls()
    {
        mainMenu.SetActive(false);
        playMenu.SetActive(false);
        controlsMenu.SetActive(true);
    }
    public void ExitGame()
    {
        Application.Quit();
    }

    public void CreateGame()
    {
        // Verberg knoppen
        createButton.SetActive(false);
        joinButton.SetActive(false);

        // Laat IP/Port zien
        connectionPanel.SetActive(true);

        // JoinGame knop blijft verborgen
        joinGameButton.SetActive(false);

        // Start host (1 speler verbonden)
        networkManager.StartHost();

        // Standaard IP/Port
        ipField.text = "localhost";
        portField.text = "7777";
    }

    public void ShowJoinFields()
    {
        // Verberg knoppen
        createButton.SetActive(false);
        joinButton.SetActive(false);

        // Laat IP/Port zien
        connectionPanel.SetActive(true);

        // JoinGame knop zichtbaar
        joinGameButton.SetActive(true);

        ipField.text = "localhost";
        portField.text = "7777";
    }

    public void JoinGame()
    {
        networkManager.networkAddress = ipField.text;

        ushort port = ushort.Parse(portField.text);
        networkManager.GetComponent<TelepathyTransport>().port = port;

        networkManager.StartClient();
    }
}
